// Shim for scripts/api.ts
export const ComfyApi = window.comfyAPI.api.ComfyApi;
export const api = window.comfyAPI.api.api;
