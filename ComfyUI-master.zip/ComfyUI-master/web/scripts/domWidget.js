// Shim for scripts/domWidget.ts
export const DOMWidgetImpl = window.comfyAPI.domWidget.DOMWidgetImpl;
